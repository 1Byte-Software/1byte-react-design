export const MESSAGE_SUCCESS_DEFAULT = 'Success';
export const MESSAGE_ERROR_DEFAULT = 'Error';
export const MESSAGE_WARNING_DEFAULT = 'Warning';
export const MESSAGE_INFO_DEFAULT = 'Info';
export const MESSAGE_OPEN_DEFAULT = 'Open';